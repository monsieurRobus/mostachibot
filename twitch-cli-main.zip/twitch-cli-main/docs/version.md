## Version

Returns the current version of the CLI.

**Args**

None.

**Flags**

None.

**Examples**

```sh
twitch version // returns current version of the CLI
```